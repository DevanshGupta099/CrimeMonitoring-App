package com.example.crime_monitoring_app

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

object CoroutineHelper {
    fun ioScope() = CoroutineScope(Dispatchers.IO)

    fun mainScope() = CoroutineScope(Dispatchers.Main)

    fun io(block: suspend () -> Unit) {
        ioScope().launch { block() }
    }

    fun main(block: suspend () -> Unit) {
        mainScope().launch { block() }
    }
}
