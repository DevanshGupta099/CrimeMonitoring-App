package com.example.crime_monitoring_app;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.Toolbar;
import androidx.preference.PreferenceManager;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.switchmaterial.SwitchMaterial;
import com.google.android.material.textfield.TextInputEditText;

public class SettingsActivity extends AppCompatActivity {

    private SwitchMaterial notificationSwitch, themeSwitch, locationSwitch;
    private TextInputEditText usernameEditText;
    private AutoCompleteTextView languageDropdown;
    private MaterialButton saveUsernameButton, resetButton, saveButton;
    private FloatingActionButton backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // Setup toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Initialize views
        notificationSwitch = findViewById(R.id.notificationSwitch);
        themeSwitch = findViewById(R.id.themeSwitch);
        locationSwitch = findViewById(R.id.locationSwitch);
        usernameEditText = findViewById(R.id.usernameEditText);
        languageDropdown = findViewById(R.id.languageDropdown);
        saveUsernameButton = findViewById(R.id.saveUsernameButton);
        resetButton = findViewById(R.id.resetButton);
        saveButton = findViewById(R.id.saveButton);
        backButton = findViewById(R.id.backButton);

        // Load settings from preferences
        loadSettings();

        // Set up the language dropdown
        setupLanguageDropdown();

        // Setup click listeners
        setupClickListeners();
    }

    private void setupLanguageDropdown() {
        String[] languages = new String[]{"English (US)", "Spanish", "French", "German", "Chinese"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_dropdown_item_1line,
                languages
        );
        languageDropdown.setAdapter(adapter);
    }

    private void loadSettings() {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);

        // Load switches states
        boolean notificationsEnabled = preferences.getBoolean("notifications_enabled", true);
        boolean darkThemeEnabled = preferences.getBoolean("dark_theme_enabled", false);
        boolean locationTrackingEnabled = preferences.getBoolean("location_tracking_enabled", false);

        notificationSwitch.setChecked(notificationsEnabled);
        themeSwitch.setChecked(darkThemeEnabled);
        locationSwitch.setChecked(locationTrackingEnabled);

        // Apply theme if it's enabled
        if (darkThemeEnabled) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }

        // Load username
        String username = preferences.getString("username", "");
        usernameEditText.setText(username);

        // Load selected language
        String selectedLanguage = preferences.getString("selected_language", "English (US)");
        languageDropdown.setText(selectedLanguage);
    }

    private void saveSettings() {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = preferences.edit();

        // Save switches states
        editor.putBoolean("notifications_enabled", notificationSwitch.isChecked());
        editor.putBoolean("dark_theme_enabled", themeSwitch.isChecked());
        editor.putBoolean("location_tracking_enabled", locationSwitch.isChecked());

        // Save username
        String username = usernameEditText.getText().toString();
        editor.putString("username", username);

        // Save selected language
        String selectedLanguage = languageDropdown.getText().toString();
        editor.putString("selected_language", selectedLanguage);

        editor.apply();

        // Apply theme changes
        if (themeSwitch.isChecked()) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }

        Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show();
    }

    private void resetSettings() {
        // Reset switches to default values
        notificationSwitch.setChecked(true);
        themeSwitch.setChecked(false);
        locationSwitch.setChecked(false);

        // Clear username
        usernameEditText.setText("");

        // Reset language to default
        languageDropdown.setText("English (US)");

        Toast.makeText(this, "Settings reset to default", Toast.LENGTH_SHORT).show();
    }

    private void setupClickListeners() {
        // Username save button
        saveUsernameButton.setOnClickListener(v -> {
            String username = usernameEditText.getText().toString();
            if (!username.isEmpty()) {
                SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
                SharedPreferences.Editor editor = preferences.edit();
                editor.putString("username", username);
                editor.apply();
                Toast.makeText(this, "Username saved", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Username cannot be empty", Toast.LENGTH_SHORT).show();
            }
        });

        // Theme switch listener
        themeSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            AppCompatDelegate.setDefaultNightMode(
                    isChecked ? AppCompatDelegate.MODE_NIGHT_YES : AppCompatDelegate.MODE_NIGHT_NO
            );
        });

        // Save button
        saveButton.setOnClickListener(v -> saveSettings());

        // Reset button
        resetButton.setOnClickListener(v -> resetSettings());

        // Back button
        backButton.setOnClickListener(v -> {
            saveSettings();
            navigateToMainActivity();
        });
    }

    private void navigateToMainActivity() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }

    @Override
    public boolean onSupportNavigateUp() {
        navigateToMainActivity();
        return true;
    }

    @Override
    public void onBackPressed() {
        saveSettings();
        super.onBackPressed();
    }
}