package com.example.crime_monitoring_app;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.preference.PreferenceManager;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {
    private ImageView reportCrimeButton, viewCrimesButton, settingsButton, logoutButton, heatmapButton, emergencyButton;
    private ImageView profileIcon;
    private Uri imageUri;
    private static final int PICK_IMAGE_REQUEST = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        checkLoginStatus();
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        profileIcon = findViewById(R.id.profileIcon);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_home);
        }

        initializeViews();
        loadProfileImage();
        setupClickListeners();

        emergencyButton.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.emergencysos_scaled));
    }

    private void checkLoginStatus() {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        boolean isLoggedIn = preferences.getBoolean("isLoggedIn", false);
        if (!isLoggedIn) {
            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
        }
    }

    @SuppressLint("WrongViewCast")
    private void initializeViews() {
        reportCrimeButton = findViewById(R.id.reportCrimeButton);
        viewCrimesButton = findViewById(R.id.viewCrimesButton);
        settingsButton = findViewById(R.id.settingsButton);
        logoutButton = findViewById(R.id.logoutButton);
        emergencyButton = findViewById(R.id.emergencyButton);
        heatmapButton = findViewById(R.id.heatmapButton);
        profileIcon = findViewById(R.id.profileIcon);
    }

    private void loadProfileImage() {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        String profileImageUri = preferences.getString("profile_image", null);
        if (profileImageUri != null) {
            Uri imageUri = Uri.parse(profileImageUri);
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), imageUri);
                profileIcon.setImageBitmap(bitmap);
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(MainActivity.this, "Failed to load profile image", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void setupClickListeners() {
        reportCrimeButton.setOnClickListener(v -> {
            Toast.makeText(MainActivity.this, "Report Crime Clicked", Toast.LENGTH_SHORT).show();
            openReportCrimeActivity();
        });

        viewCrimesButton.setOnClickListener(v -> {
            Toast.makeText(MainActivity.this, "View Crimes Clicked", Toast.LENGTH_SHORT).show();
            openViewCrimesActivity();
        });

        settingsButton.setOnClickListener(v -> {
            Toast.makeText(MainActivity.this, "Settings Clicked", Toast.LENGTH_SHORT).show();
            openSettingsActivity();
        });

        logoutButton.setOnClickListener(v -> {
            Toast.makeText(MainActivity.this, "Logout Clicked", Toast.LENGTH_SHORT).show();
            performLogout();
        });

        emergencyButton.setOnClickListener(v -> showEmergencyConfirmationDialog());

        heatmapButton.setOnClickListener(v -> {
            Toast.makeText(MainActivity.this, "Heatmap Clicked", Toast.LENGTH_SHORT).show();
            openHeatmapActivity();
        });

        profileIcon.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, UserProfileActivity.class));
        });
    }

    private void chooseImage() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            imageUri = data.getData();
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), imageUri);
                profileIcon.setImageBitmap(bitmap);
                saveProfileImage(imageUri);
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(this, "Failed to select image", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void saveProfileImage(Uri uri) {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("profile_image", uri.toString());
        editor.apply();
    }

    private void openReportCrimeActivity() {
        Intent intent = new Intent(MainActivity.this, ReportCrimeActivity.class);
        startActivity(intent);
    }

    private void openViewCrimesActivity() {
        Intent intent = new Intent(MainActivity.this, ViewCrimesActivity.class);
        startActivity(intent);
    }

    private void openSettingsActivity() {
        Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
        startActivity(intent);
    }

    private void openHeatmapActivity() {
        Intent intent = new Intent(MainActivity.this, HeatmapActivity.class);
        startActivity(intent);
    }

    private void performLogout() {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean("isLoggedIn", false);
        editor.apply();
        Toast.makeText(MainActivity.this, "Logged out successfully", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(MainActivity.this, LoginActivity.class);
        startActivity(intent);
        finish();
    }

    private void showEmergencyConfirmationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setTitle("Emergency SOS")
                .setMessage("Are you sure you want to alert nearby authorities of your location?")
                .setPositiveButton("Yes", (dialog, which) -> showEmergencyAlertedDialog())
                .setNegativeButton("No", (dialog, which) -> dialog.dismiss());
        AlertDialog dialog = builder.create();
        dialog.setOnShowListener(dialogInterface -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(ContextCompat.getColor(this, android.R.color.black));
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(ContextCompat.getColor(this, android.R.color.black));
        });
        dialog.show();
    }

    private void showEmergencyAlertedDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setTitle("Emergency SOS")
                .setMessage("Nearby authorities have been alerted of your location and will be reaching your location as soon as possible.")
                .setPositiveButton("OK", null);
        AlertDialog dialog = builder.create();
        dialog.setOnShowListener(dialogInterface -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(ContextCompat.getColor(this, android.R.color.black)));
        dialog.show();
    }

    @Override
    public boolean onSupportNavigateUp() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
        return true;
    }
}
